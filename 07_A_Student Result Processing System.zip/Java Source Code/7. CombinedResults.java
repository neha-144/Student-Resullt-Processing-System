package Admin;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.table.DefaultTableModel;

public class CombinedResults extends JFrame {

	private JPanel contentPane;
	private JComboBox<String> comboBox;
	private JTable table;
	private JScrollPane scrollPane;
	private JComboBox comboBox_1;
	private JButton btnNewButton;
	private JButton btnNewButton_6;
	private JComboBox comboBox_2;
	private JComboBox comboBox_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CombinedResults frame = new CombinedResults();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the frame.
	 */
	public CombinedResults() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ashmina Dangat\\Videos\\Captures\\A. P. Shah Institute of Technology, Thane - APSIT - \u092E\u0941\u0916\u092A\u0943\u0937\u094D\u0920 _ Facebook - Google Chrome 13-10-2021 00_19_37.png"));
		setTitle("Admin Home");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1550, 830);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\download_adobespark.png"));
		lblNewLabel.setBounds(318, 0, 127, 139);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PARSHVANATH CHARITABLE TRUST'S");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 22));
		lblNewLabel_1.setBounds(577, 10, 462, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("A.P SHAH INSITUTE OF TECHNOLOGY, THANE");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 28));
		lblNewLabel_2.setBounds(474, 48, 652, 27);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\"We build dreams.\"");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.ITALIC, 21));
		lblNewLabel_3.setBounds(670, 85, 257, 27);
		contentPane.add(lblNewLabel_3);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(28, 224, 1483, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBounds(28, 149, 1483, 2);
		contentPane.add(separator_1);
		
		JButton btnNewButton_11 = new JButton("Export to Excel sheet");
		btnNewButton_11.setBackground(Color.WHITE);
		btnNewButton_11.setForeground(new Color(0, 128, 0));
		btnNewButton_11.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();
		        fileChooser.setDialogTitle("Specify a file save");
		        int userSelection = fileChooser.showSaveDialog(table);
		        if(userSelection == JFileChooser.APPROVE_OPTION){
		            File fileToSave = fileChooser.getSelectedFile();
		            //lets write to file
		         
		            try {
		                  FileWriter fw = new FileWriter(fileToSave);
		                BufferedWriter bw = new BufferedWriter(fw);
		                for (int i = 0;i< table.getRowCount(); i++) {
		                    for (int j = 0; j <table.getColumnCount(); j++) {
		                        //write
		                        bw.write(table.getValueAt(i, j).toString()+",");
		                    }
		                    bw.newLine();//record per line 
		                }
		                JOptionPane.showMessageDialog(null, "Successfull");
		                bw.close();
		                fw.close();
		            } catch (IOException ex) {
		            	JOptionPane.showMessageDialog(null, "Error");
		               
		            }
		            
		            
		        }
			}
		});
		btnNewButton_11.setBounds(1204, 23, 209, 34);
		contentPane.add(btnNewButton_11);
		
		JButton btnNewButton_5 = new JButton("BACK");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new AdminHome().setVisible(true);
			}
		});
		btnNewButton_5.setFont(new Font("Times New Roman", Font.PLAIN, 21));
		btnNewButton_5.setBounds(686, 740, 101, 25);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton = new JButton("Add New Student");
		btnNewButton.setBackground(new Color(240, 240, 240));
		btnNewButton.setBounds(113, 169, 209, 31);
		contentPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new NewStudent().setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_1 = new JButton("Add New Result");
		btnNewButton_1.setBackground(new Color(240, 240, 240));
		btnNewButton_1.setBounds(374, 169, 209, 31);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new NewResult().setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_4 = new JButton("Logout");
		btnNewButton_4.setBackground(new Color(240, 240, 240));
		btnNewButton_4.setBounds(1164, 169, 209, 31);
		contentPane.add(btnNewButton_4);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JFrame frmHomepage = new JFrame("Logout")	;	
					if(JOptionPane.showConfirmDialog(frmHomepage,"Do you want to log out?","Login error",JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
						Homepage info = new Homepage();
						Homepage.main(null);
					}
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_2 = new JButton("Registered Students");
		btnNewButton_2.setBackground(new Color(240, 240, 240));
		btnNewButton_2.setForeground(new Color(0, 0, 0));
		btnNewButton_2.setBounds(636, 169, 209, 31);
		contentPane.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new RegisteredStudents().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_3 = new JButton("All Student Result");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try
				{
					Class.forName("com.mysql.cj.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("select *from NewStudent JOIN NewResult_sem1 using (Student_id) ");
					table.setModel( net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
		            
				}
				catch(Exception evt)
				{
					JOptionPane.showMessageDialog(null,"Connection Error");
					
				}
				
				
			}
			
		});
		btnNewButton_3.setBounds(898, 169, 209, 31);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.setForeground(Color.BLUE);
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(28, 328, 1483, 281);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		scrollPane.setViewportView(table);
		
		comboBox_1 = new JComboBox();
		comboBox_1.setBackground(Color.WHITE);
		comboBox_1.setBounds(1127, 273, 167, 27);
		comboBox_1.addItem("I.T");
		comboBox_1.addItem("C.S");
		comboBox_1.addItem("Civil");
		comboBox_1.addItem("EXTC");
		comboBox_1.addItem("Mechanical");
		comboBox_1.setSelectedItem(null);
		contentPane.add(comboBox_1);
		
		btnNewButton_6 = new JButton("Search");
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Branch = (String)comboBox_1.getSelectedItem();                
                	try
    				{
    					Class.forName("com.mysql.cj.jdbc.Driver");
    					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
    					Statement st=con.createStatement();
    					ResultSet rs=st.executeQuery("select *from NewStudent JOIN NewResult_sem1 using (Student_id)  where BranchName='"+Branch+"'");
    					table.setModel( net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
    		            
    				}
    				catch(Exception evt)
    				{
    					JOptionPane.showMessageDialog(null,"Connection Error");
    					
    				}
			}
		});
		btnNewButton_6.setBounds(1333, 273, 114, 27);
		contentPane.add(btnNewButton_6);
		
		JLabel lblNewLabel_4 = new JLabel("FILTERS:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_4.setBounds(67, 250, 85, 13);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Branch Name :");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_5.setBounds(981, 279, 114, 21);
		contentPane.add(lblNewLabel_5);
		
		comboBox_2 = new JComboBox();
		comboBox_2.setBounds(623, 272, 132, 29);
		comboBox_2.addItem("Sem 1");
		comboBox_2.addItem("Sem 2");
		comboBox_2.setSelectedItem(null);
		contentPane.add(comboBox_2);
		
		JButton btnNewButton_7 = new JButton("Search");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Semester = (String)comboBox_2.getSelectedItem();
				
				if(Semester.contains("Sem 1")) {
					try
    				{
    					Class.forName("com.mysql.cj.jdbc.Driver");
    					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
    					Statement st=con.createStatement();
    					ResultSet rs=st.executeQuery("select *from NewStudent JOIN NewResult_sem1 using (Student_id)");
    					table.setModel( net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
    		            
    				}
    				catch(Exception evt)
    				{
    					JOptionPane.showMessageDialog(null,"Connection Error");
    					
    				}
					
				}
				else if(Semester.contains("Sem 2")){
					try
    				{
    					Class.forName("com.mysql.cj.jdbc.Driver");
    					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
    					Statement st=con.createStatement();
    					ResultSet rs=st.executeQuery("select *from NewStudent JOIN NewResult_sem2 using (Student_id)");
    					table.setModel( net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
    		            
    				}
    				catch(Exception evt)
    				{
    					JOptionPane.showMessageDialog(null,"Connection Error");
    					
    				}	
				}								
			}
		});
		btnNewButton_7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_7.setBounds(808, 273, 109, 27);
		contentPane.add(btnNewButton_7);
		
		JLabel lblNewLabel_6 = new JLabel("Semester :");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_6.setBounds(508, 278, 100, 13);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Division :");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_7.setBounds(50, 280, 77, 20);
		contentPane.add(lblNewLabel_7);
		
		comboBox_3 = new JComboBox();
		comboBox_3.setBounds(145, 273, 127, 27);
		comboBox_3.addItem("A");
		comboBox_3.addItem("B");
		contentPane.add(comboBox_3);
		
		JButton btnNewButton_8 = new JButton("Search");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Division = (String)comboBox_3.getSelectedItem();				
					try
    				{
    					Class.forName("com.mysql.cj.jdbc.Driver");
    					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
    					Statement st=con.createStatement();
    					ResultSet rs=st.executeQuery("select *from NewStudent JOIN NewResult_sem1 using (Student_id) where Division='"+Division+"'");
    					table.setModel( net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
    		            
    				}
    				catch(Exception evt)
    				{
    					JOptionPane.showMessageDialog(null,"Connection Error");
    					
    				}	
				
			}
		});
		btnNewButton_8.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_8.setBounds(318, 273, 109, 27);
		contentPane.add(btnNewButton_8);
		
	}
	protected Icon ResizeImage(String path) {
		// TODO Auto-generated method stub
		return null;
	}
}
