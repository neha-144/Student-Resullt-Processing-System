package Admin;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class NewResult extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewResult frame = new NewResult();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewResult() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1550, 830);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\download_adobespark.png"));
		lblNewLabel.setBounds(318, 0, 127, 139);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PARSHVANATH CHARITABLE TRUST'S");
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 22));
		lblNewLabel_1.setBounds(577, 10, 462, 27);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("A.P SHAH INSITUTE OF TECHNOLOGY, THANE");
		lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 28));
		lblNewLabel_2.setBounds(474, 48, 652, 27);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\"We build dreams.\"");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.ITALIC, 21));
		lblNewLabel_3.setBounds(670, 85, 257, 27);
		contentPane.add(lblNewLabel_3);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(28, 224, 1483, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBounds(28, 149, 1483, 2);
		contentPane.add(separator_1);
		
		JLabel lblNewLabel_4 = new JLabel("Student Id:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_4.setBounds(383, 322, 139, 27);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Physics:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_5.setBounds(383, 389, 139, 22);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Chemistry:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_6.setBounds(383, 457, 139, 22);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Mathematics:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_7.setBounds(383, 511, 139, 22);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Mechanics:");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_8.setBounds(832, 324, 147, 22);
		contentPane.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Basic Electrical Engineering:");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_9.setBounds(832, 389, 237, 22);
		contentPane.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Total:");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_10.setBounds(832, 452, 106, 22);
		contentPane.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Percentage:");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_11.setBounds(832, 513, 126, 19);
		contentPane.add(lblNewLabel_11);
		
		JButton btnNewButton_1 = new JButton("Add New Student");
		btnNewButton_1.setBounds(112, 172, 201, 31);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new NewStudent().setVisible(true);			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_1_1 = new JButton("Add New Result");
		btnNewButton_1_1.setBounds(364, 172, 201, 31);
		contentPane.add(btnNewButton_1_1);
		btnNewButton_1_1.setForeground(Color.BLUE);
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new NewResult().setVisible(true);
			}
		});
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_2 = new JButton("Registered Students");
		btnNewButton_2.setBounds(618, 172, 201, 31);
		contentPane.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new RegisteredStudents().setVisible(true);
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_4 = new JButton("Logout");
		btnNewButton_4.setBounds(1125, 172, 201, 31);
		contentPane.add(btnNewButton_4);
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 JFrame frmHomepage = new JFrame("Logout")	;	
					if(JOptionPane.showConfirmDialog(frmHomepage,"Do you want to log out?","Login error",JOptionPane.YES_NO_OPTION)== JOptionPane.YES_NO_OPTION) {
						Homepage info = new Homepage();
						Homepage.main(null);
					}
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JButton btnNewButton_3 = new JButton("All Student Result");
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_3.setBounds(869, 172, 201, 31);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new CombinedResults().setVisible(true);
				}
		});
		

		JButton btnNewButton_5 = new JButton("BACK");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new AdminHome().setVisible(true);
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton_5.setBounds(772, 670, 127, 30);
		contentPane.add(btnNewButton_5);
		
		textField = new JTextField();
		textField.setBounds(561, 326, 85, 26);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(561, 392, 85, 23);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(560, 460, 86, 24);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(561, 515, 85, 22);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(1098, 322, 85, 26);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(1098, 384, 85, 27);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(1098, 452, 85, 24);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(1098, 511, 85, 24);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setBackground(Color.WHITE);
		comboBox.setBounds(561, 576, 85, 21);
		comboBox.addItem("1");
		comboBox.addItem("2");
		comboBox.setSelectedItem(null);
		contentPane.add(comboBox);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setForeground(Color.BLACK);
		separator_2.setBounds(746, 289, 2, 320);
		contentPane.add(separator_2);
		
		JButton btnNewButton = new JButton("CREATE");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
             double[] D = new double[13];
				
				D[1] = Double.parseDouble(textField_1.getText());
				D[2] = Double.parseDouble(textField_2.getText());
				D[3] = Double.parseDouble(textField_3.getText());
				D[4] = Double.parseDouble(textField_4.getText());
				D[5] = Double.parseDouble(textField_5.getText());
				
				
				D[6] = ( D[1] + D[2] + D[3] + D[4] + D[5]);
				D[7] = ( D[1] + D[2] + D[3] + D[4] + D[5])*100/500;
				
				String Total = String.format("%.0f", D[6]);
			    textField_6.setText(Total);
			    
			    String Percentage = String.valueOf(D[7]);
			    textField_7.setText(Percentage);
				String Student_id = textField.getText();
				String Semester = (String)comboBox.getSelectedItem();
				String Physics=textField_1.getText();
				String Chemistry=textField_2.getText();
				String Mathematics=textField_3.getText();
				String Mechanics=textField_4.getText();
				String BasicElectricalEngineering=textField_5.getText();
				String Total1=textField_6.getText();
				String Percentage1=textField_7.getText();
				
				if(Semester.contains("1")) {
					
					
					
					
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery("select *from NewStudent where Student_id ='"+Student_id+"'");
						if(rs.next())
						{
							st.executeUpdate("insert into NewResult_sem1(Student_id,Physics,Chemistry,Mathematics,Mechanics,BasicElectricalEngineering,Total,Percentage,Semester) values('"+Student_id+"','"+Physics+"','"+Chemistry+"','"+Mathematics+"','"+Mechanics+"','"+BasicElectricalEngineering+"','"+Total1+"','"+Percentage1+"','"+Semester+"')");
							JOptionPane.showMessageDialog(null,"Successfully Updated");	
							setVisible(false);
							new NewResult().setVisible(true);
						}
						else 
						{
							JOptionPane.showMessageDialog(null,"Roll number does not exist in our database");
						}
					}
						catch(Exception evt)
						{
							JOptionPane.showMessageDialog(null,"Connection error");
						}
				}
            if(Semester.contains("2")) {
					try {
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Std_data","root","Ashmina27@");
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery("select *from NewStudent where Student_id ='"+Student_id+"'");
						if(rs.next())
						{
							st.executeUpdate("insert into NewResult_sem2(Student_id,Physics,Chemistry,Mathematics,Mechanics,BasicElectricalEngineering,Total,Percentage,Semester) values('"+Student_id+"','"+Physics+"','"+Chemistry+"','"+Mathematics+"','"+Mechanics+"','"+BasicElectricalEngineering+"','"+Total1+"','"+Percentage1+"','"+Semester+"')");
							JOptionPane.showMessageDialog(null,"Successfully Updated");	
							setVisible(false);
							new NewResult().setVisible(true);
						}
						else 
						{
							JOptionPane.showMessageDialog(null,"Roll number does not exist in our database");
						}
					}
						catch(Exception evt)
						{
							JOptionPane.showMessageDialog(null,"Connection error");
						}
				}
			}
		});
		btnNewButton.setBounds(591, 670, 127, 30);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_12 = new JLabel("Semester:");
		lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_12.setBounds(383, 572, 106, 22);
		contentPane.add(lblNewLabel_12);
	}
}
