package Admin;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Color;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import javax.swing.JSeparator;
import javax.swing.ImageIcon;
import javax.swing.border.CompoundBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;

public class AdminLogin extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin frame = new AdminLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminLogin() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ashmina Dangat\\Videos\\Captures\\A. P. Shah Institute of Technology, Thane - APSIT - \u092E\u0941\u0916\u092A\u0943\u0937\u094D\u0920 _ Facebook - Google Chrome 13-10-2021 00_19_37.png"));
		setForeground(Color.WHITE);
		setBackground(Color.WHITE);
		setTitle("Admin Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1550, 830);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ashmina Dangat\\Downloads\\download_adobespark.png"));
		lblNewLabel.setBounds(318, 0, 127, 139);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_4 = new JLabel("PARSHVANATH CHARITABLE TRUST'S");
		lblNewLabel_4.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 22));
		lblNewLabel_4.setBounds(577, 10, 462, 27);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("A.P SHAH INSITUTE OF TECHNOLOGY, THANE");
		lblNewLabel_5.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 28));
		lblNewLabel_5.setBounds(474, 48, 652, 27);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("\"We build dreams.\"");
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.ITALIC, 21));
		lblNewLabel_6.setBounds(670, 85, 257, 27);
		contentPane.add(lblNewLabel_6);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.BLACK, 4, true));
		panel.setBackground(Color.WHITE);
		panel.setBounds(501, 184, 508, 461);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Admin Login");
		lblNewLabel_1.setBounds(162, 46, 197, 42);
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setBackground(Color.BLACK);
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Yu Gothic", Font.BOLD, 28));
		
		JLabel lblNewLabel_2 = new JLabel("Username :");
		lblNewLabel_2.setBounds(123, 157, 116, 27);
		panel.add(lblNewLabel_2);
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		
		textField = new JTextField();
		textField.setBounds(271, 160, 116, 27);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Password :");
		lblNewLabel_3.setBounds(123, 235, 129, 27);
		panel.add(lblNewLabel_3);
		lblNewLabel_3.setForeground(Color.BLACK);
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		
		passwordField = new JPasswordField();
		passwordField.setBounds(271, 235, 116, 27);
		panel.add(passwordField);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setBounds(123, 361, 120, 42);
		panel.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String user=textField.getText();
				String password=passwordField.getText();
				
				if(user.contains("Sakshi")&&password.contains("20104106"))
				{
					textField.setText(null);
					passwordField.setText(null);
					AdminHome info = new AdminHome();
					AdminHome.main(null);
				}
				else if(user.contains("Ashmina")&&password.contains("20104052"))
				{
					textField.setText(null);
					passwordField.setText(null);
					AdminHome info = new AdminHome();
					AdminHome.main(null);
				}	
				else if(user.contains("Neha")&&password.contains("20104134"))
				{
					textField.setText(null);
					passwordField.setText(null);
					AdminHome info = new AdminHome();
					AdminHome.main(null);
				}	
				else if(user.contains("Kritika")&&password.contains("20104102"))
				{
					textField.setText(null);
					passwordField.setText(null);
					AdminHome info = new AdminHome();
					AdminHome.main(null);
				}	
				else {
					JOptionPane.showMessageDialog(null,"Invalid Login Details","Login Error",JOptionPane.ERROR_MESSAGE);
					textField.setText(null);
					passwordField.setText(null);
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 21));
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(66, 111, 362, 2);
		panel.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBounds(66, 309, 362, 2);
		panel.add(separator_1);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setBounds(267, 361, 120, 42);
		panel.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Homepage info = new Homepage();
				Homepage.main(null);
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 21));
		setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{contentPane, lblNewLabel_1, lblNewLabel_2, textField, lblNewLabel_3, passwordField, btnNewButton, btnNewButton_1}));
	}
}
